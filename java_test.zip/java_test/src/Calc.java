public class Calc extends Main{
    public static int calcPlus(){
        return Main.b + Main.c;
    }
    public static  int calcMinus(){
        return Main.b - Main.c;
    }
    public static int calcMulti(){
        return Main.b * Main.c;
    }
    public static int calcDivid(){
        if (Main.b == 0){
            return 0;
        }
        if (Main.c == 0){
            return 0;
        }
        else{
            return Main.b / Main.c;
        }
    }
}