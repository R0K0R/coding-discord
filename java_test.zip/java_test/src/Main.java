import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static String a;
    public static int b;
    public static int c;


    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("연산자> ");
        a = sc.next();
        System.out.print("1번째 수");
        b = sc.nextInt();
        System.out.print("2번째 수");
        c = sc.nextInt();
        if (Objects.equals(a, "+")){
            System.out.println(Calc.calcPlus());
        }
        else if (Objects.equals(a, "-")){
            System.out.println(Calc.calcMinus());
        }
        else if (Objects.equals(a, "*")){
            System.out.println(Calc.calcMulti());
        }
        else if (Objects.equals(a, "/")){
            System.out.println(Calc.calcDivid());
        }
        else {
            System.out.println("+*/-만 입력할 수 있습니다.");
        }
    }
}
